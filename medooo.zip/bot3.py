#pylint:disable=W0611
import telebot,os
import re,json
import requests
import telebot,time,random
import random
import string
from telebot import types
from mojk import *
from reg import reg
from datetime import datetime, timedelta
from faker import Faker
from multiprocessing import Process
import threading
stopuser = {}
token='7115848334:AAE1vQm0aSx5Xg-qWsCXCTYpxn9y0InEQxU'
bot=telebot.TeleBot(token,parse_mode="HTML")
admin=6300836232
command_usage = {}
def reset_command_usage():
	for user_id in command_usage:
		command_usage[user_id] = {'count': 0, 'last_time': None}
@bot.message_handler(commands=["start"])
def start(message):
	def my_function():
		gate=''
		name = message.from_user.first_name
		with open('data.json', 'r') as file:
			json_data = json.load(file)
		id=message.from_user.id
		
		try:BL=(json_data[str(id)]['plan'])
		except:
			BL='𝐅𝐑𝐄𝐄'
			with open('data.json', 'r') as json_file:
				existing_data = json.load(json_file)
			new_data = {
				id : {
	  "plan": "𝐅𝐑𝐄𝐄",
	  "timer": "none",
				}
			}
	
			existing_data.update(new_data)
			with open('data.json', 'w') as json_file:
				json.dump(existing_data, json_file, ensure_ascii=False, indent=4)
		if BL == '𝐅𝐑𝐄𝐄':	
			keyboard = types.InlineKeyboardMarkup()
			contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
			keyboard.add(contact_button)
			random_number = random.randint(2, 8)
			video_url = f'https://t.me/ahmed_hussien_01/7'
			bot.send_video(chat_id=message.chat.id, video=video_url, caption=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖 {BL}</b>
	''',reply_markup=keyboard)
			return
		keyboard = types.InlineKeyboardMarkup()
	
		username = message.from_user.first_name
		random_number = random.randint(2, 8)
		video_url = f'https://t.me/ahmed_hussien_01/7/{random_number}'
		bot.send_video(chat_id=message.chat.id, video=video_url, caption='''𝐂𝐋𝐈𝐂𝐊 /cmds 𝐘𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 𝐎𝐑 𝐒𝐄𝐍𝐃 𝐓𝐇𝐄 𝐅𝐈𝐋𝐄 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐓''',reply_markup=keyboard)
	my_thread = threading.Thread(target=my_function)
	my_thread.start()
@bot.message_handler(commands=["cmds"])
def start(message):
	with open('data.json', 'r') as file:
		json_data = json.load(file)
	id=message.from_user.id
	try:BL=(json_data[str(id)]['plan'])
	except:
		BL='𝐅𝐑𝐄𝐄'
	name = message.from_user.first_name
	keyboard = types.InlineKeyboardMarkup()
	contact_button = types.InlineKeyboardButton(text=f"✨ {BL}  ✨",callback_data='plan')
	keyboard.add(contact_button)
	bot.send_message(chat_id=message.chat.id, text=f'''<b> 
𝐓𝐇𝐄𝐒𝐄 𝐀𝐑𝐄 𝐓𝐇𝐄 𝐁𝐎𝐓 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒
━━━━━━━━━━━━
 𝐁𝐑𝐀𝐈𝐍𝐓𝐑𝐄𝐄 𝐀𝐔𝐓𝐇 𝟏 ⌁ ⤹ <code>/chk number|mm|yy|cvc</code>
𝐒𝐓𝐀𝐓𝐓𝐔𝐒 𝐎𝐍𝐋𝐈𝐍𝐄 ✅
━━━━━━━━━━━━
𝐁𝐑𝐀𝐈𝐍𝐓𝐑𝐄𝐄 𝐀𝐔𝐓𝐇 𝟐 ⌁ ⤹ <code>/cc number|mm|yy|cvc</code>
𝐒𝐓𝐀𝐓𝐓𝐔𝐒 𝐎𝐍𝐋𝐈𝐍𝐄 ✅
━━━━━━━━━━━━
 𝟑𝐃 𝐋𝐎𝐎𝐊 𝐔𝐏 ⌁ ⤹ <code>/vbv number|mm|yy|cvc</code>
𝐒𝐓𝐀𝐓𝐓𝐔𝐒 𝐎𝐅𝐅𝐋𝐈𝐍𝐄 ❌
━━━━━━━━━━━━
 𝐒𝐓𝐑𝐈𝐏𝐄 𝐂𝐇𝐀𝐑𝐆𝐄 ⌁ ⤹ <code>/str number|mm|yy|cvc</code>  𝐒𝐓𝐀𝐓𝐓𝐔𝐒 𝐎𝐅𝐅𝐋𝐈𝐍𝐄 ❌
━━━━━━━━━━━━
 𝐒𝐓𝐑𝐈𝐏𝐄 𝐀𝐔𝐓𝐇 ⌁ ⤹ <code>/au number|mm|yy|cvc</code> 𝐒𝐓𝐀𝐓𝐓𝐔𝐒 𝐎𝐅𝐅𝐋𝐈𝐍𝐄 ❌
━━━━━━━━━━━━
𝐖𝐄 𝐖𝐈𝐋𝐋 𝐁𝐄 𝐀𝐃𝐃𝐈𝐍𝐆 𝐒𝐎𝐌𝐄 𝐆𝐀𝐓𝐄𝐖𝐀𝐘𝐒 𝐒𝐎𝐎𝐍 </b>
''',reply_markup=keyboard)
@bot.message_handler(content_types=["document"])
def main(message):
		name = message.from_user.first_name
		with open('data.json', 'r') as file:
			json_data = json.load(file)
		id=message.from_user.id
		
		try:BL=(json_data[str(id)]['plan'])
		except:
			BL='𝐅𝐑𝐄𝐄'
		if BL == '𝐅𝐑𝐄𝐄':
			with open('data.json', 'r') as json_file:
				existing_data = json.load(json_file)
			new_data = {
				id : {
	  "plan": "𝐅𝐑𝐄𝐄",
	  "timer": "none",
				}
			}
	
			existing_data.update(new_data)
			with open('data.json', 'w') as json_file:
				json.dump(existing_data, json_file, ensure_ascii=False, indent=4)	
			keyboard = types.InlineKeyboardMarkup()
			contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
			keyboard.add(contact_button)
			bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖 {BL}</b>
''',reply_markup=keyboard)
			return
		with open('data.json', 'r') as file:
			json_data = json.load(file)
			date_str=json_data[str(id)]['timer'].split('.')[0]
		try:
			provided_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M")
		except Exception as e:
			keyboard = types.InlineKeyboardMarkup()
			contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
			keyboard.add(contact_button)
			bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖 {BL}</b>
''',reply_markup=keyboard)
			return
		current_time = datetime.now()
		required_duration = timedelta(hours=0)
		if current_time - provided_time > required_duration:
			keyboard = types.InlineKeyboardMarkup()
			contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
			keyboard.add(contact_button)
			bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐘𝐎𝐔 𝐂𝐀𝐍𝐍'𝐓 𝐔𝐒𝐄 𝐓𝐇𝐄 𝐁𝐎𝐓 𝐁𝐄𝐂𝐀𝐔𝐒𝐄 𝐘𝐎𝐔𝐑 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 𝐖𝐀𝐒 𝐄𝐍𝐃</b>
		''',reply_markup=keyboard)
			with open('data.json', 'r') as file:
				json_data = json.load(file)
			json_data[str(id)]['timer'] = 'none'
			json_data[str(id)]['paln'] = '𝐅𝐑𝐄𝐄'
			with open('data.json', 'w') as file:
				json.dump(json_data, file, indent=2)
			return
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text=f"​​​​🇪🇬 𝐁𝐑𝐀𝐈𝐍𝐓𝐑𝐄𝐄 𝐀𝐔𝐓𝐇  🇪🇬",callback_data='br')
		sw = types.InlineKeyboardButton(text=f" ♡ 𝐒𝐓𝐑𝐈𝐏𝐄 𝐂𝐇𝐀𝐑𝐆𝐄 ♡",callback_data='str')
		keyboard.add(contact_button)
		keyboard.add(sw)
		bot.reply_to(message, text=f'𝐂𝐇𝐎𝐎𝐒𝐄 𝐓𝐇𝐄 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 𝐘𝐎𝐔 𝐖𝐀𝐍𝐓 𝐓𝐎 𝐔𝐒𝐄',reply_markup=keyboard)
		ee = bot.download_file(bot.get_file(message.document.file_id).file_path)
		with open("combo.txt", "wb") as w:
			w.write(ee)
@bot.callback_query_handler(func=lambda call: call.data == 'str')
def menu_callback(call):
	def my_function():
		id=call.from_user.id
		gate='stripe charge'
		dd = 0
		live = 0
		ch = 0
		ccnn = 0
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text= "𝐂𝐇𝐄𝐂𝐊𝐈𝐍𝐆 𝐂𝐀𝐑𝐃𝐒 𝐍𝐎𝐖..👀")
		try:
			with open("combo.txt", 'r') as file:
				lino = file.readlines()
				total = len(lino)
				try:
					stopuser[f'{id}']['status'] = 'start'
				except:
					stopuser[f'{id}'] = {
				'status': 'start'
			}
				for cc in lino:
					if stopuser[f'{id}']['status'] == 'stop':
						bot.edit_message_text(chat_id=call.chat.id, message_id=ko, text='𝐒𝐓𝐎𝐏𝐏𝐄𝐃 ✅\n𝐁𝐎𝐓 𝐁𝐘 ↯ @EG_SNIPER')
						return
					try:
						data = requests.get('https://lookup.binlist.net/'+cc[:6]).json()
						
					except:
						pass
					try:
						bank=(data['bank']['name'])
					except:
						bank=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						country_flag=(data['country']['emoji'])
					except:
						country_flag=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						country=(data['country']['name'])
					except:
						country=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						brand=(data['scheme'])
					except:
						brand=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						card_type=(data['type'])
					except:
						card_type=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						url=(data['bank']['url'])
					except:
						url=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					
					start_time = time.time()
					try:
						last = str(st(cc))
					except Exception as e:
						print(e)
						last = "ERROR"
					if 'risk' in last:
						last='declined'
					elif 'Duplicate' in last:
						last='Approved'
					mes = types.InlineKeyboardMarkup(row_width=1)
					cm1 = types.InlineKeyboardButton(f"• {cc} •", callback_data='u8')
					status = types.InlineKeyboardButton(f"• 𝐒𝐓𝐀𝐓𝐔𝐒 ➜ {last} •", callback_data='u8')
					cm3 = types.InlineKeyboardButton(f"• 𝐂𝐇𝐀𝐑𝐆𝐄 ✅ ➜ [ {ch} ] •", callback_data='x')
					ccn = types.InlineKeyboardButton(f"• 𝐂𝐂𝐍 ☑️ ➜ [ {ccnn} ] •", callback_data='x')
					cm4 = types.InlineKeyboardButton(f"• 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ​​​​​​​​​​​​​​​​​​❌ ➜ [ {dd} ] •", callback_data='x')
					risk = types.InlineKeyboardButton(f"• 𝐈𝐍𝐒𝐔𝐅𝐅 𝐈𝐂𝐈𝐄𝐍𝐓 𝐅𝐔𝐍𝐃𝐒 ☑️ ➜ [ {live} ] •", callback_data='x')
					cm5 = types.InlineKeyboardButton(f"• 𝐓𝐎𝐓𝐀𝐋 👀 ➜ [ {total} ] •", callback_data='x')
					stop=types.InlineKeyboardButton(f"[ 𝐒𝐓𝐎𝐏 ]", callback_data='stop')
					mes.add(cm1,status, cm3,ccn,risk, cm4, cm5, stop)
					end_time = time.time()
					execution_time = end_time - start_time
					bot.edit_message_text(chat_id=call.message.chat.id, 
					  message_id=call.message.message_id, 
					  text=f'''𝐏𝐋𝐄𝐀𝐒𝐄 𝐖𝐀𝐈𝐓 𝐖𝐇𝐈𝐋𝐄 𝐘𝐎𝐔𝐑 𝐂𝐀𝐑𝐃𝐒 𝐀𝐑𝐄 𝐁𝐄𝐈𝐍𝐆 𝐂𝐇𝐄𝐂𝐊 𝐀𝐓 𝐓𝐇𝐄 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 {gate} 𝐃𝐄𝐕:  @EG_SNIPER''', reply_markup=mes)
					
					msg=f'''<b>𝐂𝐇𝐀𝐑𝐆𝐄 ✅
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
					msgc=f'''<b>𝐂𝐍𝐍 ☑️
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
					msgf=f'''<b>𝐈𝐍𝐒𝐔𝐅𝐅 𝐈𝐂𝐈𝐄𝐍𝐓 𝐅𝐔𝐍𝐃𝐒 ☑️
			━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
					if 'success' in last:
						ch += 1
						bot.send_message(call.from_user.id, msg)
					elif "funds" in last:
						bot.send_message(call.from_user.id, msgf)
						live+=1
					elif "card's security" in last:
						ccnn+=1
						bot.send_message(call.from_user.id, msgc)
					else:
						dd += 1
					time.sleep(15)
		except Exception as e:
			print(e)
		stopuser[f'{id}']['status'] = 'start'
		bot.edit_message_text(chat_id=call.message.chat.id, 
					  message_id=call.message.message_id, 
					  text='𝐈𝐓 𝐂𝐎𝐌𝐏𝐋𝐄𝐓𝐄𝐃 ✅\n𝐁𝐎𝐓 𝐁𝐘 ↯ @EG_SNIPER')
	my_thread = threading.Thread(target=my_function)
	my_thread.start()
@bot.callback_query_handler(func=lambda call: call.data == 'br')
def menu_callback(call):
	def my_function():
		id=call.from_user.id
		gate='Braintree Auth'
		dd = 0
		live = 0
		riskk = 0
		ccnn = 0
		bot.edit_message_text(chat_id=call.message.chat.id,message_id=call.message.message_id,text= "𝐂𝐇𝐄𝐂𝐊𝐈𝐍𝐆 𝐂𝐀𝐑𝐃𝐒 𝐍𝐎𝐖..⌛")
		try:
			with open("combo.txt", 'r') as file:
				lino = file.readlines()
				total = len(lino)
				try:
					stopuser[f'{id}']['status'] = 'start'
				except:
					stopuser[f'{id}'] = {
				'status': 'start'
			}
				for cc in lino:
					if stopuser[f'{id}']['status'] == 'stop':
						bot.edit_message_text(chat_id=call.chat.id, message_id=ko, text='𝐒𝐓𝐎𝐏𝐏𝐄𝐃 ✅\n𝐁𝐎𝐓 𝐁𝐘 ↯ @EG_SNIPER')
						return
					try:
						data = requests.get('https://lookup.binlist.net/'+cc[:6]).json()
						
					except:
						pass
					try:
						bank=(data['bank']['name'])
					except:
						bank=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						country_flag=(data['country']['emoji'])
					except:
						country_flag=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						country=(data['country']['name'])
					except:
						country=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						brand=(data['scheme'])
					except:
						brand=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						card_type=(data['type'])
					except:
						card_type=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					try:
						url=(data['bank']['url'])
					except:
						url=('𝒖𝒏𝒌𝒏𝒐𝒘𝒏')
					
					start_time = time.time()
					try:
						last = str(scr(cc))
					except Exception as e:
						print(e)
						last = "ERROR"
					if 'risk' in last:
						last='declined'
					elif 'Duplicate' in last:
						last='Approved'
					mes = types.InlineKeyboardMarkup(row_width=1)
					cm1 = types.InlineKeyboardButton(f"• {cc} •", callback_data='u8')
					status = types.InlineKeyboardButton(f"• 𝐒𝐓𝐀𝐓𝐔𝐒 ➜ {last} •", callback_data='u8')
					cm3 = types.InlineKeyboardButton(f"• 𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅ ➜ [ {live} ] •", callback_data='x')
					ccn = types.InlineKeyboardButton(f"• 𝐂𝐂𝐍 ☑️ ➜ [ {ccnn} ] •", callback_data='x')
					cm4 = types.InlineKeyboardButton(f"• 𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ❌ ➜ [ {dd} ] •", callback_data='x')
					risk = types.InlineKeyboardButton(f"• 𝐑𝐈𝐒𝐊 🥲 ➜ [ {riskk} ] •", callback_data='x')
					cm5 = types.InlineKeyboardButton(f"• 𝐓𝐎𝐓𝐀𝐋 👀 ➜ [ {total} ] •", callback_data='x')
					stop=types.InlineKeyboardButton(f"[ 𝐒𝐓𝐎𝐏 ]", callback_data='stop')
					mes.add(cm1,status, cm3,ccn,risk, cm4, cm5, stop)
					end_time = time.time()
					execution_time = end_time - start_time
					bot.edit_message_text(chat_id=call.message.chat.id, 
					  message_id=call.message.message_id, 
					  text=f'''𝐏𝐋𝐄𝐀𝐒𝐄 𝐖𝐀𝐈𝐓 𝐖𝐇𝐈𝐋𝐄 𝐘𝐎𝐔𝐑 𝐂𝐀𝐑𝐃𝐒 𝐀𝐑𝐄 𝐁𝐄𝐈𝐍𝐆 𝐂𝐇𝐄𝐂𝐊 𝐀𝐓 𝐓𝐇𝐄 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 {gate} 𝐃𝐄𝐕: @EG_SNIPER''', reply_markup=mes)
					
					msg=f'''<b>𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃✅
━━━━━━━━━━━━━━━━			
[↯] 𝐂𝐀𝐑𝐃 ⇾ <code>{cc}</code>
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}		
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐒𝐒𝐔𝐄𝐑 ⇾ {bank}
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)}
[↯] 𝐁𝐎𝐓 𝐁𝐘 ⇾ @EG_SNIPER</b>'''
					msgc=f'''<b>𝐂𝐂𝐍 ☑️
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
					if "Funds" in last or 'Invalid postal' in last or 'avs' in last or 'added' in last or 'Duplicate' in last or 'Approved' in last:
						live += 1
						bot.send_message(call.from_user.id, msg)
					elif 'risk' in last:
						risk+=1
					elif 'CVV' in last:
						ccnn+=1
						bot.send_message(call.from_user.id, msgc)
					else:
						dd += 1
					time.sleep(4)
		except Exception as e:
			print(e)
		stopuser[f'{id}']['status'] = 'start'
		bot.edit_message_text(chat_id=call.message.chat.id, 
					  message_id=call.message.message_id, 
					  text='𝐈𝐓 𝐂𝐎𝐌𝐋𝐄𝐓𝐄𝐃 ✅\n 𝐁𝐘: @EG_SNIPER')
	my_thread = threading.Thread(target=my_function)
	my_thread.start()
@bot.message_handler(func=lambda message: message.text.lower().startswith('.au') or message.text.lower().startswith('/au'))
def respond_to_vbv(message):
	gate='stripe Auth'
	name = message.from_user.first_name
	idt=message.from_user.id
	id=message.chat.id
	with open('data.json', 'r') as json_file:
		json_data = json.load(json_file)

	try:BL=(json_data[str(idt)]['plan'])
	except:
		with open('data.json', 'r') as json_file:
			existing_data = json.load(json_file)
		new_data = {
			id : {
  "plan": "𝐅𝐑𝐄𝐄",
  "timer": "none",
			}
		}
		existing_data.update(new_data)
		with open('data.json', 'w') as json_file:
			json.dump(existing_data, json_file, ensure_ascii=False, indent=4)	
		BL='𝐅𝐑𝐄𝐄'
	if BL == '𝐅𝐑𝐄𝐄':
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖  {BL}</b>
''',reply_markup=keyboard)
		return
	with open('data.json', 'r') as file:
		json_data = json.load(file)
		date_str=json_data[str(id)]['timer'].split('.')[0]
	try:
		provided_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M")
	except Exception as e:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖  {BL}</b>
''',reply_markup=keyboard)
		return
	current_time = datetime.now()
	required_duration = timedelta(hours=0)
	if current_time - provided_time > required_duration:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐘𝐎𝐔 𝐂𝐀𝐍𝐍 𝐓 𝐔𝐒𝐄 𝐓𝐇𝐄 𝐁𝐎𝐓 𝐁𝐄𝐂𝐀𝐔𝐒𝐄 𝐘𝐎𝐔𝐑 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 𝐖𝐀𝐒 𝐄𝐍𝐃</b>
	''',reply_markup=keyboard)
		with open('data.json', 'r') as file:
			json_data = json.load(file)
		json_data[str(id)]['timer'] = 'none'
		json_data[str(id)]['paln'] = '𝐅𝐑𝐄𝐄'
		with open('data.json', 'w') as file:
			json.dump(json_data, file, indent=2)
		return
	try:command_usage[idt]['last_time']
	except:command_usage[idt] = {
				'last_time': datetime.now()
			}
	if command_usage[idt]['last_time'] is not None:
		time_diff = (current_time - command_usage[idt]['last_time']).seconds
		if time_diff < 30:
			bot.reply_to(message, f"<b>Try again after {30-time_diff} seconds.</b>",parse_mode="HTML")
			return	
	ko = (bot.reply_to(message, "𝐂𝐇𝐄𝐂𝐊𝐈𝐍𝐆 𝐂𝐀𝐑𝐃𝐒 𝐍𝐎𝐖 /..⌛").message_id)
	try:
		cc = message.reply_to_message.text
	except:
		cc=message.text
	cc=str(reg(cc))
	if cc == 'None':
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
Please ensure you enter the card details in the correct format:
Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
		return
	start_time = time.time()
	try:
		command_usage[idt]['last_time'] = datetime.now()
		last = str(scc(cc))
	except Exception as e:
		last='Error'
	try: data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6]).json()
	except: pass
	try:
		brand = data['brand']
	except:
		brand = 'Unknown'
	try:
		card_type = data['type']
	except:
		card_type = 'Unknown'
	try:
		country = data['country_name']
		country_flag = data['country_flag']
	except:
		country = 'Unknown'
		country_flag = 'Unknown'
	try:
		bank = data['bank']
	except:
		bank = 'Unknown'
	end_time = time.time()
	execution_time = end_time - start_time
	msg=f'''<b>𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msgd=f'''<b>𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ❌
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄 {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	if "Funds" in last or 'Invalid postal' in last or 'avs' in last or 'added' in last or 'Duplicate' in last or 'Approved' in last:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
	else:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)
@bot.message_handler(func=lambda message: message.text.lower().startswith('.chk') or message.text.lower().startswith('/chk'))
def respond_to_vbv(message):
	gate='Braintree Auth 1'
	name = message.from_user.first_name
	idt=message.from_user.id
	id=message.chat.id
	with open('data.json', 'r') as json_file:
		json_data = json.load(json_file)

	try:BL=(json_data[str(idt)]['plan'])
	except:
		with open('data.json', 'r') as json_file:
			existing_data = json.load(json_file)
		new_data = {
			id : {
  "plan": "𝐅𝐑𝐄𝐄",
  "timer": "none",
			}
		}
		existing_data.update(new_data)
		with open('data.json', 'w') as json_file:
			json.dump(existing_data, json_file, ensure_ascii=False, indent=4)	
		BL='𝐅𝐑𝐄𝐄'
	if BL == '𝐅𝐑𝐄𝐄':
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖
 {BL}</b>
''',reply_markup=keyboard)
		return
	with open('data.json', 'r') as file:
		json_data = json.load(file)
		date_str=json_data[str(id)]['timer'].split('.')[0]
	try:
		provided_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M")
	except Exception as e:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖
 {BL}</b>
''',reply_markup=keyboard)
		return
	current_time = datetime.now()
	required_duration = timedelta(hours=0)
	if current_time - provided_time > required_duration:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐘𝐎𝐔 𝐂𝐀𝐍𝐍𝐎𝐓 𝐔𝐒𝐄 𝐓𝐇𝐄 𝐁𝐎𝐓 𝐁𝐄𝐂𝐀𝐔𝐒𝐄 𝐘𝐎𝐔𝐑 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 𝐖𝐀𝐒 𝐄𝐍𝐃</b>
	''',reply_markup=keyboard)
		with open('data.json', 'r') as file:
			json_data = json.load(file)
		json_data[str(id)]['timer'] = 'none'
		json_data[str(id)]['paln'] = '𝐅𝐑𝐄𝐄'
		with open('data.json', 'w') as file:
			json.dump(json_data, file, indent=2)
		return
	try:command_usage[idt]['last_time']
	except:command_usage[idt] = {
				'last_time': datetime.now()
			}
	if command_usage[idt]['last_time'] is not None:
		time_diff = (current_time - command_usage[idt]['last_time']).seconds
		if time_diff < 30:
			bot.reply_to(message, f"<b>Try again after {30-time_diff} seconds.</b>",parse_mode="HTML")
			return	
	ko = (bot.reply_to(message, "𝐂𝐇𝐄𝐂𝐊𝐈𝐍𝐆 𝐂𝐀𝐑𝐃𝐒 𝐍𝐎𝐖..⌛").message_id)
	try:
		cc = message.reply_to_message.text
	except:
		cc=message.text
	cc=str(reg(cc))
	if cc == 'None':
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
Please ensure you enter the card details in the correct format:
Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
		return
	start_time = time.time()
	try:
		command_usage[idt]['last_time'] = datetime.now()
		last = str(scr(cc))
	except Exception as e:
		last='Error'
	try: data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6]).json()
	except: pass
	try:
		brand = data['brand']
	except:
		brand = 'Unknown'
	try:
		card_type = data['type']
	except:
		card_type = 'Unknown'
	try:
		country = data['country_name']
		country_flag = data['country_flag']
	except:
		country = 'Unknown'
		country_flag = 'Unknown'
	try:
		bank = data['bank']
	except:
		bank = 'Unknown'
	end_time = time.time()
	execution_time = end_time - start_time
	msg=f'''<b>𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅ 
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msgc=f'''<b>𝐂𝐍𝐍 ☑️
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
━━━━━━━━━━━━━━━━
[↯] 𝐁𝐘 ⇾@EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msgd=f'''<b>𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ​​​​​​​​​​​​​​​​​​❌
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 ⇾@EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	if "Funds" in last or 'Invalid postal' in last or 'avs' in last or 'added' in last or 'Duplicate' in last or 'Approved' in last:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
	elif "CVV" in last :
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgc)
	else:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)
@bot.message_handler(func=lambda message: message.text.lower().startswith('.cc') or message.text.lower().startswith('/cc'))
def respond_to_vbv(message):
	gate='Braintree Auth 2'
	name = message.from_user.first_name
	idt=message.from_user.id
	id=message.chat.id
	with open('data.json', 'r') as json_file:
		json_data = json.load(json_file)

	try:BL=(json_data[str(idt)]['plan'])
	except:
		with open('data.json', 'r') as json_file:
			existing_data = json.load(json_file)
		new_data = {
			id : {
  "plan": "𝐅𝐑𝐄𝐄",
  "timer": "none",
			}
		}
		existing_data.update(new_data)
		with open('data.json', 'w') as json_file:
			json.dump(existing_data, json_file, ensure_ascii=False, indent=4)	
		BL='𝐅𝐑𝐄𝐄'
	if BL == '𝐅𝐑𝐄𝐄':
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖
 {BL}</b>
''',reply_markup=keyboard)
		return
	with open('data.json', 'r') as file:
		json_data = json.load(file)
		date_str=json_data[str(id)]['timer'].split('.')[0]
	try:
		provided_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M")
	except Exception as e:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖
 {BL}</b>
''',reply_markup=keyboard)
		return
	current_time = datetime.now()
	required_duration = timedelta(hours=0)
	if current_time - provided_time > required_duration:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐘𝐎𝐔 𝐂𝐀𝐍𝐍𝐎𝐓 𝐔𝐒𝐄 𝐓𝐇𝐄 𝐁𝐎𝐓 𝐁𝐄𝐂𝐀𝐔𝐒𝐄 𝐘𝐎𝐔𝐑 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 𝐖𝐀𝐒 𝐄𝐍𝐃</b>
	''',reply_markup=keyboard)
		with open('data.json', 'r') as file:
			json_data = json.load(file)
		json_data[str(id)]['timer'] = 'none'
		json_data[str(id)]['paln'] = '𝐅𝐑𝐄𝐄'
		with open('data.json', 'w') as file:
			json.dump(json_data, file, indent=2)
		return
	try:command_usage[idt]['last_time']
	except:command_usage[idt] = {
				'last_time': datetime.now()
			}
	if command_usage[idt]['last_time'] is not None:
		time_diff = (current_time - command_usage[idt]['last_time']).seconds
		if time_diff < 30:
			bot.reply_to(message, f"<b>Try again after {30-time_diff} seconds.</b>",parse_mode="HTML")
			return	
	ko = (bot.reply_to(message, "𝐂𝐇𝐄𝐂𝐊𝐈𝐍𝐆 𝐂𝐀𝐑𝐃𝐒 𝐍𝐎𝐖..⌛").message_id)
	try:
		cc = message.reply_to_message.text
	except:
		cc=message.text
	cc=str(reg(cc))
	if cc == 'None':
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
Please ensure you enter the card details in the correct format:
Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
		return
	start_time = time.time()
	try:
		command_usage[idt]['last_time'] = datetime.now()
		last = str(scr(cc))
	except Exception as e:
		last='Error'
	try: data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6]).json()
	except: pass
	try:
		brand = data['brand']
	except:
		brand = 'Unknown'
	try:
		card_type = data['type']
	except:
		card_type = 'Unknown'
	try:
		country = data['country_name']
		country_flag = data['country_flag']
	except:
		country = 'Unknown'
		country_flag = 'Unknown'
	try:
		bank = data['bank']
	except:
		bank = 'Unknown'
	end_time = time.time()
	execution_time = end_time - start_time
	msg=f'''<b>𝐀𝐏𝐏𝐑𝐎𝐕𝐄𝐃 ✅ 
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msgc=f'''<b>𝐂𝐍𝐍 ☑️
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
━━━━━━━━━━━━━━━━
[↯] 𝐁𝐘 ⇾@EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msgd=f'''<b>𝐃𝐄𝐂𝐋𝐈𝐍𝐄𝐃 ​​​​​​​​​​​​​​​​​​❌
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 ⇾@EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	if "Funds" in last or 'Invalid postal' in last or 'avs' in last or 'added' in last or 'Duplicate' in last or 'Approved' in last:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
	elif "CVV" in last :
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgc)
	else:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)
@bot.message_handler(func=lambda message: message.text.lower().startswith('.str') or message.text.lower().startswith('/str'))
def respond_to_vbv(message):
	gate='stripe charge'
	name = message.from_user.first_name
	idt=message.from_user.id
	id=message.chat.id
	with open('data.json', 'r') as json_file:
		json_data = json.load(json_file)

	try:BL=(json_data[str(idt)]['plan'])
	except:
		with open('data.json', 'r') as json_file:
			existing_data = json.load(json_file)
		new_data = {
			id : {
  "plan": "𝐅𝐑𝐄𝐄",
  "timer": "none",
			}
		}
		existing_data.update(new_data)
		with open('data.json', 'w') as json_file:
			json.dump(existing_data, json_file, ensure_ascii=False, indent=4)	
		BL='𝐅𝐑𝐄𝐄'
	if BL == '𝐅𝐑𝐄𝐄':
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖 {BL}</b>
''',reply_markup=keyboard)
		return
	with open('data.json', 'r') as file:
		json_data = json.load(file)
		date_str=json_data[str(id)]['timer'].split('.')[0]
	try:
		provided_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M")
	except Exception as e:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖 {BL}</b>
''',reply_markup=keyboard)
		return
	current_time = datetime.now()
	required_duration = timedelta(hours=0)
	if current_time - provided_time > required_duration:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐘𝐎𝐔 𝐂𝐀𝐍𝐍𝐎𝐓 𝐔𝐒𝐄 𝐓𝐇𝐄 𝐁𝐎𝐓 𝐁𝐄𝐂𝐀𝐔𝐒𝐄 𝐘𝐎𝐔𝐑 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 𝐖𝐀𝐒 𝐄𝐍𝐃</b>
	''',reply_markup=keyboard)
		with open('data.json', 'r') as file:
			json_data = json.load(file)
		json_data[str(id)]['timer'] = 'none'
		json_data[str(id)]['paln'] = '𝐅𝐑𝐄𝐄'
		with open('data.json', 'w') as file:
			json.dump(json_data, file, indent=2)
		return
	try:command_usage[idt]['last_time']
	except:command_usage[idt] = {
				'last_time': datetime.now()
			}
	if command_usage[idt]['last_time'] is not None:
		time_diff = (current_time - command_usage[idt]['last_time']).seconds
		if time_diff < 30:
			bot.reply_to(message, f"<b>Try again after {30-time_diff} seconds.</b>",parse_mode="HTML")
			return	
	ko = (bot.reply_to(message, "𝐂𝐇𝐄𝐂𝐊𝐈𝐍𝐆 𝐂𝐀𝐑𝐃𝐒 𝐍𝐎𝐖..⌛").message_id)
	try:
		cc = message.reply_to_message.text
	except:
		cc=message.text
	cc=str(reg(cc))
	if cc == 'None':
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
Please ensure you enter the card details in the correct format:
Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
		return
	start_time = time.time()
	try:
		command_usage[idt]['last_time'] = datetime.now()
		last = str(st(cc))
	except Exception as e:
		last='Error'
		print(e)
	try: data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6]).json()
	except: pass
	try:
		brand = data['brand']
	except:
		brand = 'Unknown'
	try:
		card_type = data['type']
	except:
		card_type = 'Unknown'
	try:
		country = data['country_name']
		country_flag = data['country_flag']
	except:
		country = 'Unknown'
		country_flag = 'Unknown'
	try:
		bank = data['bank']
	except:
		bank = 'Unknown'
	end_time = time.time()
	execution_time = end_time - start_time
	msgd=f'''<b>𝐑𝐄𝐆𝐄𝐂𝐓𝐄𝐃 ❌
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>
[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msg=f'''<b>𝐂𝐇𝐀𝐑𝐆𝐄 🥀
			━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msgc=f'''<b>𝐂𝐍𝐍 ☑️
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msgf=f'''<b>𝐈𝐍𝐒𝐔𝐅𝐅 𝐈𝐂𝐈𝐄𝐍𝐓 𝐅𝐔𝐍𝐃𝐒 ☑️
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>
[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	if 'success' in last:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
	elif "funds" in last:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgf)
	elif "card's security" in last:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgc)
	else:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)
@bot.message_handler(func=lambda message: message.text.lower().startswith('.redeem') or message.text.lower().startswith('/redeem'))
def respond_to_vbv(message):
	def my_function():
		global stop
		try:
			re=message.text.split(' ')[1]
			with open('data.json', 'r') as file:
				json_data = json.load(file)
			timer=(json_data[re]['time'])
			typ=(json_data[f"{re}"]["plan"])
			json_data[f"{message.from_user.id}"]['timer'] = timer
			json_data[f"{message.from_user.id}"]['plan'] = typ
			with open('data.json', 'w') as file:
				json.dump(json_data, file, indent=2)
			with open('data.json', 'r') as json_file:
				data = json.load(json_file)
			del data[re]
			with open('data.json', 'w') as json_file:
				json.dump(data, json_file, ensure_ascii=False, indent=4)
			msg=f'''<b>𝐌𝐄𝐃𝐎 𝐕𝐈𝐏 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐁𝐄𝐃 ✅
𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 𝐄𝐍𝐃 ➜  {timer}
𝐓𝐘𝐏 ➜ {typ}</b>'''
			bot.reply_to(message,msg,parse_mode="HTML")
		except Exception as e:
			print('ERROR : ',e)
			bot.reply_to(message,'<b>Incorrect code or it has already been redeemed </b>',parse_mode="HTML")
	my_thread = threading.Thread(target=my_function)
	my_thread.start()
@bot.message_handler(commands=["code"])
def start(message):
	def my_function():
		id=message.from_user.id
		if not id ==admin:
			return
		try:
			h=float(message.text.split(' ')[1])
			with open('data.json', 'r') as json_file:
				existing_data = json.load(json_file)
			characters = string.ascii_uppercase + string.digits
			pas ='𝐌𝐄𝐃𝐎-'+''.join(random.choices(characters, k=4))+'-'+''.join(random.choices(characters, k=4))+'-'+''.join(random.choices(characters, k=4))
			current_time = datetime.now()
			ig = current_time + timedelta(hours=h)
			plan='𝐕𝐈𝐏'
			parts = str(ig).split(':')
			ig = ':'.join(parts[:2])
			with open('data.json', 'r') as json_file:
				existing_data = json.load(json_file)
			new_data = {
				pas : {
	  "plan": plan,
	  "time": ig,
			}
			}
			existing_data.update(new_data)
			with open('data.json', 'w') as json_file:
				json.dump(existing_data, json_file, ensure_ascii=False, indent=4)	
			msg=f'''<b>𝐍𝐄𝐖 𝐊𝐄𝐘 𝐂𝐑𝐄𝐀𝐓𝐄𝐃 🚀
		
𝐏𝐋𝐀𝐍 ⇾ {plan}
𝐄𝐗𝐏𝐈𝐑𝐄𝐒 𝐈𝐍 ⇾ {ig}
𝐊𝐄𝐘 ⇾ <code>{pas}</code>
		
𝐔𝐒𝐄 /redeem [𝙺𝙴𝚈]</b>'''
			bot.reply_to(message,msg,parse_mode="HTML")
		except Exception as e:
			print('ERROR : ',e)
			bot.reply_to(message,e,parse_mode="HTML")
	my_thread = threading.Thread(target=my_function)
	my_thread.start()
@bot.message_handler(func=lambda message: message.text.lower().startswith('.vbv') or message.text.lower().startswith('/vbv'))
def respond_to_vbv(message):
	id=message.from_user.id
	name = message.from_user.first_name
	gate='3D Lookup'
	with open('data.json', 'r') as file:
		json_data = json.load(file)
	try:BL=(json_data[str(id)]['plan'])
	except:
		with open('data.json', 'r') as json_file:
			existing_data = json.load(json_file)
		new_data = {
			id : {
  "plan": "𝐅𝐑𝐄𝐄",
  "timer": "none",
			}
		}
		BL='𝐅𝐑𝐄𝐄'
		existing_data.update(new_data)
		with open('data.json', 'w') as json_file:
			json.dump(existing_data, json_file, ensure_ascii=False, indent=4)	
	if BL == '𝐅𝐑𝐄𝐄':
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖 {BL}</b>
''',reply_markup=keyboard)
		return
	with open('data.json', 'r') as file:
		json_data = json.load(file)
		date_str=json_data[str(id)]['timer'].split('.')[0]
	try:
		provided_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M")
	except Exception as e:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐇𝐄𝐋𝐋𝐎 {name}
𝐓𝐇𝐈𝐒 𝐏𝐀𝐑𝐓 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒𝐍 𝐓 𝐅𝐑𝐄𝐄 𝐈𝐅 𝐘𝐎𝐔 𝐍𝐄𝐄𝐃 𝐓𝐎 𝐂𝐇𝐄𝐂𝐊 𝐈𝐍 𝐈𝐓 𝐘𝐎𝐔 𝐌𝐔𝐒𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 

𝐓𝐇𝐄 𝐉𝐎𝐁 𝐎𝐅 𝐁𝐎𝐓 𝐈𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐀𝐑𝐃𝐒

𝐁𝐎𝐓 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍:

𝐄𝐆𝐘𝐏𝐓 ➜  🇪🇬
𝟏 𝐃𝐀𝐘 ➜ 𝟑𝟎 𝐄𝐆
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟐𝟎𝟎 𝐄𝐆
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟓𝟎𝟎 𝐄𝐆

𝐈𝐑𝐀𝐐 ➜  🇮🇶
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐀𝐒𝐈𝐀
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐀𝐒𝐈𝐀 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐀𝐒𝐈𝐀

𝐖𝐎𝐑𝐋𝐃 𝐖𝐈𝐃𝐄 ➜ 🌏 𝐔𝐒𝐃𝐓
𝟏 𝐃𝐀𝐘 ➜ 𝟏$ 𝐔𝐒𝐃𝐓
𝟏 𝐖𝐄𝐄𝐊 ➜ 𝟓$ 𝐔𝐒𝐃𝐓 
𝟏 𝐌𝐎𝐍𝐓𝐇 ➜ 𝟏𝟖$ 𝐔𝐒𝐃𝐓 

𝐂𝐋𝐈𝐂𝐊 /cmds 𝐓𝐎 𝐕𝐈𝐄𝐖 𝐓𝐇𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 

𝐘𝐎𝐔𝐑 𝐏𝐋𝐀𝐍 𝐍𝐎𝐖 {BL}</b>
''',reply_markup=keyboard)
		return
	current_time = datetime.now()
	required_duration = timedelta(hours=0)
	if current_time - provided_time > required_duration:
		keyboard = types.InlineKeyboardMarkup()
		contact_button = types.InlineKeyboardButton(text="✨ 𝐎𝐖𝐍𝐄𝐑  ✨", url="https://t.me/EG_SNIPER")
		keyboard.add(contact_button)
		bot.send_message(chat_id=message.chat.id, text=f'''<b>𝐘𝐎𝐔 𝐂𝐀𝐍𝐍𝐎𝐓 𝐔𝐒𝐄 𝐓𝐇𝐄 𝐁𝐎𝐓 𝐁𝐄𝐂𝐀𝐔𝐒𝐄 𝐘𝐎𝐔𝐑 𝐒𝐔𝐁𝐒𝐂𝐑𝐈𝐏𝐓𝐈𝐎𝐍 𝐖𝐀𝐒 𝐄𝐍𝐃</b>
	''',reply_markup=keyboard)
		with open('data.json', 'r') as file:
			json_data = json.load(file)
		json_data[str(id)]['timer'] = 'none'
		json_data[str(id)]['paln'] = '𝐅𝐑𝐄𝐄'
		with open('data.json', 'w') as file:
			json.dump(json_data, file, indent=2)
		return
	ko = (bot.reply_to(message, "𝐂𝐇𝐄𝐂𝐊𝐈𝐍𝐆 𝐂𝐀𝐑𝐃𝐒 𝐍𝐎𝐖..⌛").message_id)
	try:
		cc = message.reply_to_message.text
	except:
		cc=message.text
	cc=str(reg(cc))
	if cc == 'None':
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
Please ensure you enter the card details in the correct format:
Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
		return
	start_time = time.time()
	try:
		response = requests.post(
		f'https://rimuruchkbot.alwaysdata.net/vbv.php?bin={cc}')
		last=(response.json()['result'])
		if 'result not found' in last:
			last='Authenticate Frictionless Failed'
	except Exception as e:
		last='Error'
	try: data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6]).json()
	except: pass
	try:
		brand = data['brand']
	except:
		brand = 'Unknown'
	try:
		card_type = data['type']
	except:
		card_type = 'Unknown'
	try:
		country = data['country_name']
		country_flag = data['country_flag']
	except:
		country = 'Unknown'
		country_flag = 'Unknown'
	try:
		bank = data['bank']
	except:
		bank = 'Unknown'
	end_time = time.time()
	execution_time = end_time - start_time
	msg=f'''<b>𝐏𝐀𝐒𝐒𝐄𝐃 ✅ 
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	msgd=f'''<b>𝐑𝐄𝐆𝐄𝐂𝐓𝐄𝐃 ❌
━━━━━━━━━━━━━━━━
[↯] 𝐂𝐂 ⇾ <code>{cc}</code>

[↯] 𝐆𝐀𝐓𝐄𝐖𝐀𝐘 ⇾ {gate}
[↯] 𝐑𝐄𝐒𝐏𝐎𝐍𝐒𝐄 ⇾ {last}
[↯] 𝐁𝐈𝐍 ⇾ {cc[:6]}
[↯] 𝐈𝐍𝐅𝐎 ⇾ {card_type} - {brand}
[↯] 𝐁𝐀𝐍𝐊 ⇾ {bank}
[↯] 𝐂𝐎𝐔𝐍𝐓𝐑𝐘 ⇾ {country} - {country_flag} 
[↯] 𝐁𝐘 : @EG_SNIPER
[↯] 𝐓𝐈𝐌𝐄: {"{:.1f}".format(execution_time)} 𝐒𝐄𝐂𝐎𝐔𝐍𝐃𝐒 .</b>'''
	if 'Authenticate Attempt Successful' in last or 'Authenticate Successful' in last or 'authenticate_successful' in last:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
	else:
		bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text= msgd)
@bot.callback_query_handler(func=lambda call: call.data == 'stop')
def menu_callback(call):
	id=call.from_user.id
	stopuser[f'{id}']['status'] = 'stop'
print("تم تشغيل البوت")
while True:
	try:
		bot.polling(none_stop=True)
	except Exception as e:
		print(f"حدث خطأ: {e}")